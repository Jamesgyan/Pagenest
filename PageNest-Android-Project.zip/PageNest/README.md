# PageNest — Android PDF Reader

A lightweight, offline Android PDF reader. Import PDFs from your phone, read one page at a time, swipe left/right or use Previous/Next, and automatically resume each document from its last-read page.

## Features
- Import PDFs using Android's document picker (no broad storage permission required).
- Personal library of imported documents.
- Page-by-page rendering using Android's built-in `PdfRenderer`.
- Swipe left/right and Previous/Next controls.
- Automatically saves the last page separately for each PDF, including when leaving the reader or closing the app.
- Reading progress indicator.
- Offline; PDF access and progress are stored locally on the device.

## Build an installable APK
This workspace did not have the Android SDK or Gradle installed, so an APK could not be compiled here. To build it:
1. Install **Android Studio** on a computer.
2. Extract this ZIP and open the `PageNest` folder in Android Studio (`File → Open`).
3. Allow Android Studio to install the Android Gradle Plugin and Android SDK Platform 35 if prompted.
4. Wait for Gradle Sync to finish.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will show the APK location; typically `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to your Android phone and install it. You may need to allow installation from that file manager/browser.

## Notes
- Minimum Android version: Android 6.0 (API 23).
- Package: `com.pagenest.reader`
- App name: `PageNest PDF Reader`
- Imported documents remain in their original location; Android's document provider grants the app persistent read access where supported. If you delete or move the original PDF, you may need to import it again.
