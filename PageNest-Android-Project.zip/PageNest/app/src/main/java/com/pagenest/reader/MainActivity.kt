package com.pagenest.reader

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable
import java.io.FileNotFoundException
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("pagenest_library", MODE_PRIVATE) }
    private val books = linkedMapOf<String, Book>()
    private var readerUri: Uri? = null
    private var renderer: PdfRenderer? = null
    private var descriptor: ParcelFileDescriptor? = null
    private var currentPage = 0
    private var pageCount = 0
    private lateinit var root: LinearLayout
    private lateinit var pageImage: ImageView
    private lateinit var pageLabel: TextView
    private lateinit var progress: ProgressBar
    private lateinit var readerTitle: TextView
    private val pickPdf = 41

    data class Book(val uri: String, val name: String, var page: Int, var total: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(247,247,252)
        window.navigationBarColor = Color.rgb(247,247,252)
        loadBooks()
        showLibrary()
    }

    private fun loadBooks() {
        books.clear()
        val all = prefs.all
        all.keys.filter { it.startsWith("book_") }.forEach { key ->
            val uri = key.removePrefix("book_")
            val raw = prefs.getString(key, "") ?: ""
            val parts = raw.split("|")
            if (parts.size >= 3) books[uri] = Book(uri, parts[0], parts[1].toIntOrNull() ?: 0, parts[2].toIntOrNull() ?: 0)
        }
    }

    private fun saveBook(book: Book) {
        books[book.uri] = book
        prefs.edit().putString("book_${book.uri}", "${book.name}|${book.page}|${book.total}").apply()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(bg: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply { setColor(bg); cornerRadius = dp(radius).toFloat() }
    private fun text(value: String, size: Float, color: Int = 0xFF202033.toInt(), bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }
    private fun button(value: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = value; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = rounded(0xFF5B5BD6.toInt(), 14); setPadding(dp(18), dp(13), dp(18), dp(13)); setOnClickListener { onClick() }
    }
    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(18)); setBackgroundColor(0xFFF7F7FC.toInt())
    }
    private fun showLibrary() {
        closePdf(); root = base()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.addView(text("PageNest", 28f, 0xFF252544.toInt(), true))
        heading.addView(text("Your personal reading space", 13f, 0xFF77778D.toInt()))
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("＋  Add PDF") { openPicker() })
        root.addView(header)
        val sub = text("MY LIBRARY", 12f, 0xFF85859A.toInt(), true).apply { setPadding(0, dp(30), 0, dp(12)) }
        root.addView(sub)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (books.isEmpty()) {
            val empty = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(55), dp(20), dp(55)); background = rounded(Color.WHITE) }
            empty.addView(text("▤", 48f, 0xFF7777D8.toInt()).apply { gravity = Gravity.CENTER })
            empty.addView(text("Your next chapter starts here", 18f, 0xFF292943.toInt(), true).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(6)) })
            empty.addView(text("Add a PDF to start reading. PageNest will remember where you stop.", 14f, 0xFF77778D.toInt()).apply { gravity = Gravity.CENTER })
            list.addView(empty)
        } else {
            books.values.toList().reversed().forEach { book ->
                val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = rounded(Color.WHITE); setPadding(dp(15), dp(16), dp(15), dp(16)) }
                val cover = TextView(this).apply { text = "PDF"; textSize = 14f; setTextColor(0xFF5555C7.toInt()); gravity = Gravity.CENTER; background = rounded(0xFFECEBFF.toInt(), 12) }
                card.addView(cover, LinearLayout.LayoutParams(dp(54), dp(68)))
                val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), 0, dp(8), 0) }
                info.addView(text(book.name, 16f, 0xFF28283F.toInt(), true))
                val totalText = if (book.total > 0) " of ${book.total}" else ""
                info.addView(text("Last read: page ${book.page + 1}$totalText", 13f, 0xFF77778D.toInt()).apply { setPadding(0, dp(5), 0, dp(7)) })
                val pct = if (book.total > 0) ((book.page + 1) * 100 / book.total).coerceIn(0,100) else 0
                val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = pct; progressTintList = android.content.res.ColorStateList.valueOf(0xFF6868D9.toInt()); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFFE9E9F2.toInt()) }
                info.addView(bar, LinearLayout.LayoutParams(-1, dp(5)))
                card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                card.setOnClickListener { openBook(book) }
                val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(12); list.addView(card, lp)
            }
        }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        startActivityForResult(intent, pickPdf)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickPdf && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val name = queryName(uri)
            val book = books[uri.toString()] ?: Book(uri.toString(), name, 0, 0)
            openBook(book)
        }
    }

    private fun queryName(uri: Uri): String {
        var name = "PDF document"
        try { contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name } } catch (_: Exception) {}
        return name
    }

    private fun openBook(book: Book) {
        try {
            closePdf(); readerUri = Uri.parse(book.uri)
            descriptor = contentResolver.openFileDescriptor(readerUri!!, "r") ?: throw FileNotFoundException()
            renderer = PdfRenderer(descriptor!!); pageCount = renderer!!.pageCount
            currentPage = book.page.coerceIn(0, max(0, pageCount - 1))
            saveBook(Book(book.uri, book.name, currentPage, pageCount))
            showReader(book.name); renderPage()
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open this PDF. Please select it again.", Toast.LENGTH_LONG).show(); showLibrary()
        }
    }

    private fun showReader(name: String) {
        root = base(); root.setPadding(dp(14), dp(12), dp(14), dp(12))
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val back = text("‹", 34f, 0xFF5555C7.toInt(), true).apply { gravity = Gravity.CENTER; setOnClickListener { saveProgress(); showLibrary() } }
        top.addView(back, LinearLayout.LayoutParams(dp(42), dp(48)))
        readerTitle = text(name, 16f, 0xFF292943.toInt(), true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        top.addView(readerTitle, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(text("Aa", 17f, 0xFF6666C8.toInt(), true).apply { setPadding(dp(12), dp(10), dp(5), dp(10)); setOnClickListener { Toast.makeText(this@MainActivity, "PDF page view", Toast.LENGTH_SHORT).show() } })
        root.addView(top)
        pageImage = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.WHITE); setPadding(dp(5), dp(5), dp(5), dp(5)) }
        val pageHolder = FrameLayout(this).apply { setBackgroundColor(0xFFEDEDF3.toInt()); setPadding(dp(7), dp(7), dp(7), dp(7)); addView(pageImage, FrameLayout.LayoutParams(-1, -1)) }
        root.addView(pageHolder, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(12); bottomMargin = dp(12) })
        pageImage.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) { MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; return true }; MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX; val dy = event.y - downY
                    if (kotlin.math.abs(dx) > dp(55) && kotlin.math.abs(dx) > kotlin.math.abs(dy)) { if (dx < 0) nextPage() else previousPage() }; return true
                } }
                return true
            }
        })
        pageLabel = text("Page 1 of $pageCount", 13f, 0xFF66667D.toInt(), true).apply { gravity = Gravity.CENTER }
        root.addView(pageLabel)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progressTintList = android.content.res.ColorStateList.valueOf(0xFF6868D9.toInt()) }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(8); bottomMargin = dp(12) })
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        controls.addView(button("‹  Previous") { previousPage() }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        controls.addView(button("Next  ›") { nextPage() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(controls)
        setContentView(root)
    }

    private fun renderPage() {
        val r = renderer ?: return
        try {
            r.openPage(currentPage).use { page ->
                val width = max(500, (resources.displayMetrics.widthPixels - dp(48)))
                val height = max(700, (width * page.height.toFloat() / page.width).toInt())
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(Color.WHITE); page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                pageImage.setImageBitmap(bitmap)
            }
            pageLabel.text = "Page ${currentPage + 1} of $pageCount"
            progress.progress = ((currentPage + 1) * 100 / max(1, pageCount))
            saveProgress()
        } catch (_: Exception) { Toast.makeText(this, "Unable to render this page", Toast.LENGTH_SHORT).show() }
    }
    private fun nextPage() { if (currentPage < pageCount - 1) { currentPage++; renderPage() } else Toast.makeText(this, "You've reached the last page", Toast.LENGTH_SHORT).show() }
    private fun previousPage() { if (currentPage > 0) { currentPage--; renderPage() } }
    private fun saveProgress() { val uri = readerUri ?: return; val old = books[uri.toString()]; saveBook(Book(uri.toString(), old?.name ?: queryName(uri), currentPage, pageCount)) }
    private fun closePdf() { try { renderer?.close() } catch (_: Exception) {}; try { descriptor?.close() } catch (_: Exception) {}; renderer = null; descriptor = null; readerUri = null }
    override fun onPause() { saveProgress(); super.onPause() }
    override fun onDestroy() { saveProgress(); closePdf(); super.onDestroy() }
    override fun onBackPressed() { if (renderer != null) { saveProgress(); showLibrary() } else super.onBackPressed() }
}
